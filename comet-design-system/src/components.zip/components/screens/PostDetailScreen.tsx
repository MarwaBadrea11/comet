import { useState } from 'react'
import { motion } from 'framer-motion'
import { useNavigate, useParams } from 'react-router-dom'
import { ArrowLeft, Heart, MessageCircle, Share2, Bookmark, MoreHorizontal, ThumbsUp, Loader2, Send } from 'lucide-react'
import { Avatar } from '../ui/Avatar'
import { Button } from '../ui/Button'
import { motionVariants } from '../../lib/theme'
import { usePost, useReactToPost } from '../../hooks/usePostsQuery'
import { usePostComments, useCreateComment } from '../../hooks/useCommentsQuery'
import { useAuthStore } from '../../stores/authStore'

export function PostDetailScreen() {
  const navigate = useNavigate()
  const { id }   = useParams<{ id: string }>()
  const user     = useAuthStore(s => s.user)

  const [newComment, setNewComment] = useState('')

  // ── Queries ────────────────────────────────────────────────────────────────
  const { data: post, isLoading, isError, error } = usePost(id ?? '')
  const { data: comments = [], isLoading: loadingComments }  = usePostComments(id ?? '')

  // ── Mutations ──────────────────────────────────────────────────────────────
  const reactToPost    = useReactToPost()
  const createComment  = useCreateComment()

  // ── Derived ────────────────────────────────────────────────────────────────
  const isLiked = post?.reactions?.some(r => r.userId === user?.id) ?? false

  const handleLike = () => {
    if (!post || !user) return
    reactToPost.mutate({ postId: String(post.id), userId: user.id })
  }

  const handleSubmitComment = (e: React.FormEvent) => {
    e.preventDefault()
    if (!newComment.trim() || !post || !user) return

    createComment.mutate(
      { postId: String(post.id), userId: user.id, content: newComment.trim() },
      { onSuccess: () => setNewComment('') },
    )
  }

  if (isLoading) {
    return <div className="min-h-screen flex items-center justify-center"><Loader2 className="w-10 h-10 text-primary animate-spin" /></div>
  }

  if (isError || !post) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-4 px-4 text-center">
        <p className="text-on-surface-variant font-medium">{(error as any)?.response?.data?.message ?? 'Post not found.'}</p>
        <Button variant="secondary" onClick={() => navigate(-1)}>Go Back</Button>
      </div>
    )
  }

  return (
    <div className="max-w-4xl mx-auto py-8 md:py-12 px-4 md:px-8 pb-32">

      {/* Back */}
      <div className="mb-8 md:mb-10 flex items-center gap-2">
        <button onClick={() => navigate(-1)} className="p-2 hover:bg-surface-container-low rounded-full transition-colors">
          <ArrowLeft size={20} className="text-primary" />
        </button>
        <span className="text-sm font-medium text-on-surface-variant">Back to Feed</span>
      </div>

      {/* Post card */}
      <motion.article {...motionVariants.fadeIn} className="bg-surface-container-lowest rounded-[2rem] md:rounded-[2.5rem] p-6 md:p-10 relative mb-12 md:mb-16 shadow-[0_20px_40px_rgba(107,70,192,0.06)] overflow-visible">
        <div className="absolute -top-5 -left-5 h-16 w-16 md:h-20 md:w-20 rounded-2xl bg-surface-container-lowest p-1 shadow-xl">
          <Avatar
            src={post.user?.avatar || `https://api.dicebear.com/7.x/adventurer/svg?seed=${encodeURIComponent(post.user?.name ?? 'User')}`}
            alt={post.user?.name} size="lg" className="rounded-2xl"
          />
        </div>

        <div className="pl-10 md:pl-12">
          <div className="flex justify-between items-start mb-4 md:mb-6">
            <div>
              <h2 className="text-lg md:text-2xl font-bold font-headline text-on-surface">{post.user?.name}</h2>
              <p className="text-on-surface-variant text-xs md:text-sm">
                {new Date(post.createdAt).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
                {post.location && <> · <span className="text-primary">{post.location}</span></>}
              </p>
            </div>
            <button className="text-on-surface-variant hover:text-primary transition-colors"><MoreHorizontal size={20} /></button>
          </div>

          <p className="text-base md:text-lg font-body text-on-surface-variant leading-relaxed mb-6 md:mb-10 whitespace-pre-wrap">{post.content}</p>

          {(post.hashtags?.length ?? 0) > 0 && (
            <div className="flex flex-wrap gap-2 mb-6">
              {post.hashtags!.map(t => <span key={t.id} className="text-xs font-extrabold text-primary hover:underline cursor-pointer">#{t.name}</span>)}
            </div>
          )}

          {(post.media?.length ?? 0) > 0 && (
            <div className="rounded-2xl md:rounded-3xl overflow-hidden mb-6 md:mb-10">
              {post.media!.map(m => <img key={m.id} src={m.url} alt="Post media" className="w-full object-cover max-h-[500px]" />)}
            </div>
          )}

          {/* Actions */}
          <div className="flex items-center gap-4 md:gap-8 py-4 md:py-6 border-t border-surface-container-low">
            {[
              { icon: <Heart size={20} fill={isLiked ? 'currentColor' : 'none'} />, label: String(post.reactions?.length ?? 0), active: isLiked, action: handleLike },
              { icon: <MessageCircle size={20} />, label: String(comments.length), active: false, action: () => {} },
              { icon: <Share2 size={20} />, label: 'Share', active: false, action: () => {} },
            ].map((a, i) => (
              <button key={i} onClick={a.action} className={`flex items-center gap-2 group cursor-pointer transition-colors ${a.active ? 'text-primary' : 'text-on-surface-variant hover:text-primary'}`}>
                <div className="h-9 w-9 md:h-10 md:w-10 flex items-center justify-center rounded-full bg-surface-container-low group-hover:bg-primary/10 transition-colors">{a.icon}</div>
                <span className="font-bold text-on-surface text-sm">{a.label}</span>
              </button>
            ))}
            <div className="ml-auto">
              <Button variant="secondary" size="sm" icon={<Bookmark size={16} />}>Save</Button>
            </div>
          </div>
        </div>
      </motion.article>

      {/* Comment input */}
      <form onSubmit={handleSubmitComment} className="mb-8 md:mb-12 flex gap-3 md:gap-4 items-start">
        <Avatar src={`https://api.dicebear.com/7.x/adventurer/svg?seed=${encodeURIComponent(user?.name ?? 'user')}`} alt="Me" size="sm" className="shrink-0 mt-1" />
        <div className="flex-1 bg-surface-container-lowest rounded-2xl border border-outline-variant/15 shadow-sm flex items-end gap-2 px-4 py-3">
          <textarea
            value={newComment}
            onChange={e => setNewComment(e.target.value)}
            placeholder="Add your thoughts to the cosmos..."
            className="flex-1 bg-transparent border-none resize-none focus:ring-0 text-sm outline-none min-h-[40px] max-h-24"
            rows={1}
          />
          <button type="submit" disabled={createComment.isPending || !newComment.trim()} className="p-2 rounded-xl bg-primary text-white hover:bg-primary/90 transition-colors disabled:opacity-50 shrink-0">
            {createComment.isPending ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
          </button>
        </div>
      </form>

      {/* Comments */}
      <section>
        <h3 className="text-2xl md:text-3xl font-extrabold font-headline text-on-surface tracking-tight mb-6 md:mb-8">The Conversation</h3>

        {loadingComments ? (
          <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 text-primary animate-spin" /></div>
        ) : comments.length === 0 ? (
          <div className="text-center py-12 text-on-surface-variant text-sm bg-surface-container-low rounded-2xl border-2 border-dashed border-outline-variant/20">
            No comments yet. Be the first to contribute!
          </div>
        ) : (
          <div className="bg-surface-container-low rounded-[2rem] md:rounded-[2.5rem] p-5 md:p-8 space-y-6 md:space-y-8">
            {comments.map(c => (
              <div key={c.id} className="flex gap-4 md:gap-6">
                <Avatar src={`https://api.dicebear.com/7.x/adventurer/svg?seed=${encodeURIComponent(c.user?.name ?? 'user')}`} alt={c.user?.name} size="md" className="rounded-2xl shrink-0" />
                <div className="flex-1 bg-surface-container-lowest p-4 md:p-6 rounded-2xl md:rounded-3xl shadow-sm border border-white/20">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-bold text-on-surface text-sm">{c.user?.name ?? 'Anonymous'}</span>
                    {c.createdAt && <span className="text-[10px] text-on-surface-variant">{new Date(c.createdAt).toLocaleDateString()}</span>}
                  </div>
                  <p className="text-on-surface-variant leading-relaxed text-sm">{c.content}</p>
                  <div className="mt-3 flex items-center gap-4">
                    <button className="text-primary text-xs font-bold flex items-center gap-1"><ThumbsUp size={13} /> Like</button>
                    <button className="text-on-surface-variant text-xs font-bold hover:text-primary">Reply</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Sticky bar */}
      <div className="fixed bottom-8 md:bottom-12 left-1/2 -translate-x-1/2 z-50">
        <div className="bg-on-surface/90 backdrop-blur-xl text-white px-5 md:px-8 py-3 md:py-4 rounded-full flex items-center gap-6 md:gap-10 shadow-2xl shadow-primary/20">
          {[
            { icon: <Heart size={18} fill={isLiked ? 'currentColor' : 'none'} />, label: 'Like',    action: handleLike },
            { icon: <MessageCircle size={18} />,                                   label: 'Comment', action: () => {} },
            { icon: <Share2 size={18} />,                                          label: 'Share',   action: () => {} },
          ].map((a, i) => (
            <button key={i} onClick={a.action} className="flex items-center gap-2 hover:text-primary transition-colors">
              {a.icon}
              <span className="text-xs md:text-sm font-bold">{a.label}</span>
              {i < 2 && <div className="w-px h-4 bg-white/20 ml-4 md:ml-10" />}
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}
