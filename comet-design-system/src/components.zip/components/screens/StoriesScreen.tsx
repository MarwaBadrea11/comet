import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useNavigate } from 'react-router-dom'
import { X, ChevronLeft, ChevronRight, Heart, Share2, Bookmark, Send, Loader2 } from 'lucide-react'
import { Avatar } from '../ui/Avatar'
import { useFeed } from '../../hooks/usePostsQuery'
import { useReactToPost } from '../../hooks/usePostsQuery'
import { useCreateConversation, useSendMessage } from '../../hooks/useMessagesQuery'
import { useAuthStore } from '../../stores/authStore'

export function StoriesScreen() {
  const navigate    = useNavigate()
  const user        = useAuthStore(s => s.user)

  const [currentIndex, setCurrentIndex] = useState(0)
  const [replyText, setReplyText]        = useState('')

  // ── Data ───────────────────────────────────────────────────────────────────
  // Reuse the feed cache — no extra request
  const { data: feed = [], isLoading, isError } = useFeed()
  const stories = feed.filter(p => p.type === 'STORY')

  const reactToPost       = useReactToPost()
  const createConversation = useCreateConversation()
  const sendMessage       = useSendMessage()

  const currentStory = stories[currentIndex]

  // ── Navigation ─────────────────────────────────────────────────────────────
  const handleNext = () => {
    if (currentIndex < stories.length - 1) setCurrentIndex(i => i + 1)
    else navigate('/home')
  }
  const handlePrev = () => { if (currentIndex > 0) setCurrentIndex(i => i - 1) }

  // ── Like ───────────────────────────────────────────────────────────────────
  const handleLike = () => {
    if (!currentStory || !user) return
    reactToPost.mutate({ postId: String(currentStory.id), userId: user.id })
  }

  // ── Reply ──────────────────────────────────────────────────────────────────
  const handleSendReply = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!replyText.trim() || !currentStory || !user) return

    try {
      // 1. Open / reuse a DM conversation
      const conv = await createConversation.mutateAsync({
        participantIds: [String(currentStory.user.id)],
        type: 'DIRECT',
      })

      // 2. Send the reply as a message
      await sendMessage.mutateAsync({
        conversationId: String(conv.id),
        content:        `Replied to your story: "${replyText}"`,
        senderId:       user.id,
      })

      setReplyText('')
      alert('Reply sent via Direct Messages!')
    } catch (err: any) {
      alert(err.response?.data?.message || 'Could not deliver reply.')
    }
  }

  const isSendingReply = createConversation.isPending || sendMessage.isPending

  // ── Loading / error / empty ────────────────────────────────────────────────
  if (isLoading) {
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center gap-4">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
        <p className="text-sm font-medium text-white/60">Entering the celestial orbit...</p>
      </div>
    )
  }

  if (isError || stories.length === 0) {
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center p-6 text-center">
        <p className="text-white/80 font-medium mb-4">{isError ? 'Could not load stories.' : 'No active stories in your orbit right now.'}</p>
        <button onClick={() => navigate('/home')} className="px-6 h-11 bg-primary text-white font-bold rounded-xl text-sm">Return Home</button>
      </div>
    )
  }

  const isLikedByMe    = currentStory.reactions?.some(r => r.userId === user?.id) ?? false
  const reactionsCount = currentStory.reactions?.length ?? 0

  return (
    <div className="min-h-screen bg-[#090A0F] text-white flex items-center justify-center relative overflow-hidden select-none">

      {/* Blurred background */}
      <div className="absolute inset-0 z-0 opacity-20 blur-[120px] scale-125 pointer-events-none">
        <img src={currentStory.media?.[0]?.url || 'https://images.unsplash.com/photo-1451187580459-43490279c0fa'} alt="" className="w-full h-full object-cover" />
      </div>

      {/* Close */}
      <button onClick={() => navigate('/home')} className="absolute top-6 right-6 z-50 bg-white/10 hover:bg-white/20 text-white p-2.5 rounded-full backdrop-blur-md border border-white/10 transition-colors">
        <X size={20} />
      </button>

      {/* Desktop nav arrows */}
      <div className="absolute inset-x-6 top-1/2 -translate-y-1/2 justify-between items-center hidden md:flex z-30">
        <button onClick={handlePrev} disabled={currentIndex === 0} className="bg-white/5 hover:bg-white/15 text-white p-4 rounded-full backdrop-blur-md border border-white/5 transition-all disabled:opacity-20 disabled:cursor-not-allowed">
          <ChevronLeft size={24} />
        </button>
        <button onClick={handleNext} className="bg-white/5 hover:bg-white/15 text-white p-4 rounded-full backdrop-blur-md border border-white/5 transition-all">
          <ChevronRight size={24} />
        </button>
      </div>

      {/* Story card */}
      <div className="relative z-10 w-full max-w-[440px] h-screen sm:h-[88vh] sm:rounded-[2.5rem] overflow-hidden bg-black shadow-[0_32px_80px_rgba(0,0,0,0.8)] border border-white/5 flex flex-col">

        {/* Progress bar */}
        <div className="absolute top-4 inset-x-4 z-40 flex gap-1.5 px-2">
          {stories.map((s, idx) => (
            <div key={s.id} className="h-[3px] flex-1 bg-white/20 rounded-full overflow-hidden">
              <div className={`h-full bg-white transition-all duration-300 ${idx < currentIndex ? 'w-full' : idx === currentIndex ? 'w-1/2 animate-pulse' : 'w-0'}`} />
            </div>
          ))}
        </div>

        {/* Story header */}
        <div className="absolute top-8 inset-x-0 z-40 p-6 flex items-center bg-gradient-to-b from-black/60 to-transparent">
          <Avatar
            src={currentStory.user.avatar || `https://api.dicebear.com/7.x/adventurer/svg?seed=${encodeURIComponent(currentStory.user.name)}`}
            alt={currentStory.user.name} size="sm" className="border-2 border-primary mr-3"
          />
          <div>
            <h4 className="font-headline font-bold text-sm text-white">{currentStory.user.name}</h4>
            <span className="text-[11px] text-white/60 font-medium">
              {new Date(currentStory.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </span>
          </div>
        </div>

        {/* Story body */}
        <div className="flex-grow relative bg-neutral-950 flex items-center justify-center">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentStory.id}
              initial={{ opacity: 0, scale: 1.02 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.3 }} className="w-full h-full"
              onClick={e => {
                const rect = e.currentTarget.getBoundingClientRect()
                if (e.clientX - rect.left > rect.width / 2) handleNext()
                else handlePrev()
              }}
            >
              {(currentStory.media?.length ?? 0) > 0 ? (
                <img src={currentStory.media![0].url} alt="Story" className="w-full h-full object-cover pointer-events-none" />
              ) : (
                <div className="w-full h-full flex items-center justify-center p-8 bg-gradient-to-tr from-[#6B46C0] to-[#00D4FF] text-center">
                  <p className="font-headline font-bold text-2xl leading-snug">{currentStory.content}</p>
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Bottom bar */}
        <div className="relative z-40 p-6 pb-8 bg-gradient-to-t from-black/90 via-black/40 to-transparent flex flex-col gap-5">
          <form onSubmit={handleSendReply} className="flex items-center gap-3 bg-white/10 backdrop-blur-xl border border-white/15 p-1.5 pl-4 rounded-full">
            <input
              type="text" value={replyText} onChange={e => setReplyText(e.target.value)}
              className="bg-transparent border-none text-white placeholder-white/40 focus:ring-0 text-sm flex-grow outline-none"
              placeholder={`Reply to ${currentStory.user.name.split(' ')[0]}...`}
            />
            <button type="submit" disabled={isSendingReply || !replyText.trim()} className="bg-primary text-white p-2.5 rounded-full disabled:opacity-40 active:scale-95 transition-transform">
              {isSendingReply ? <Loader2 size={15} className="animate-spin" /> : <Send size={15} />}
            </button>
          </form>

          <div className="flex justify-around items-center text-white/70 pt-1">
            <button onClick={handleLike} className={`flex flex-col items-center gap-1 transition-colors group ${isLikedByMe ? 'text-red-500' : 'hover:text-white'}`}>
              <Heart size={22} fill={isLikedByMe ? 'currentColor' : 'none'} className="group-hover:scale-110 transition-transform" />
              <span className="text-[10px] font-label font-bold uppercase">{reactionsCount} Likes</span>
            </button>
            <button className="flex flex-col items-center gap-1 hover:text-white transition-colors group">
              <Share2 size={22} className="group-hover:scale-110 transition-transform" />
              <span className="text-[10px] font-label font-bold uppercase">Share</span>
            </button>
            <button className="flex flex-col items-center gap-1 hover:text-white transition-colors group">
              <Bookmark size={22} className="group-hover:scale-110 transition-transform" />
              <span className="text-[10px] font-label font-bold uppercase">Save</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
