import { useState, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { X, Rocket, Trash2, Image as ImageIcon, Loader2, Smile } from 'lucide-react'
import EmojiPicker from 'emoji-picker-react'
import type { EmojiClickData } from 'emoji-picker-react'
import { Button } from '../ui/Button'
import { motionVariants } from '../../lib/theme'
import { useCreatePost } from '../../hooks/usePostsQuery'
import api from '../../services/api'

interface Props {
  open: boolean
  onClose: () => void
  onCreated?: () => void
}

const VISIBILITY_OPTIONS = [
  { id: 'PUBLIC', label: 'Universal', desc: 'Visible to every curator in the galaxy.', icon: 'public' },
  { id: 'FRIENDS_ONLY', label: 'Inner Circle', desc: 'Only shared with your trusted satellite groups.', icon: 'group_work' },
  { id: 'PRIVATE', label: 'Private Drift', desc: 'Stored in your personal archive only.', icon: 'lock' },
] as const

type Visibility = typeof VISIBILITY_OPTIONS[number]['id']

export function CreatePostModal({ open, onClose, onCreated }: Props) {
  const [content, setContent] = useState('')
  const [visibility, setVisibility] = useState<Visibility>('PUBLIC')
  const [feeling, setFeeling] = useState('')
  const [location, setLocation] = useState('')
  const [mediaIds, setMediaIds] = useState<string[]>([])
  const [isUploading, setIsUploading] = useState(false)
  const [showEmojiPicker, setShowEmojiPicker] = useState(false)
  
  const fileInputRef = useRef<HTMLInputElement>(null)
  const createPost = useCreatePost()

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files || files.length === 0) return
    setIsUploading(true)
    try {
      const uploadedIds: string[] = []
      for (const file of Array.from(files)) {
        const formData = new FormData()
        formData.append('file', file)
        const response = await api.post('/media/upload', formData, {
          headers: { 'Content-Type': undefined },
        })
        if (response.data?.id) uploadedIds.push(response.data.id)
      }
      setMediaIds(prev => [...prev, ...uploadedIds])
    } catch (err) {
      console.error("Upload failed", err)
    } finally {
      setIsUploading(false)
    }
  }

  const handlePost = () => {
    createPost.mutate({ content, visibility, mediaIds, feeling, location }, {
      onSuccess: () => { setContent(''); setMediaIds([]); onClose(); onCreated?.() }
    })
  }

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div {...motionVariants.modalBackdrop} className="fixed inset-0 z-[100] bg-on-surface/10 backdrop-blur-sm" onClick={onClose} />
          <motion.div {...motionVariants.scaleIn} className="fixed inset-0 z-[101] flex items-center justify-center p-4 md:p-8">
            <div className="bg-surface w-full max-w-4xl max-h-[90vh] rounded-[2rem] flex flex-col overflow-visible border border-outline-variant/15">
              <div className="px-10 py-8 flex items-center justify-between border-b border-outline-variant/10">
                <h2 className="font-headline text-2xl font-bold text-on-surface">New Cosmic Thread</h2>
                <button onClick={onClose}><X size={20} /></button>
              </div>

              <div className="flex-1 overflow-y-auto px-10 py-8">
                <textarea
                  value={content}
                  onChange={e => setContent(e.target.value)}
                  className="w-full h-32 bg-transparent border-none resize-none focus:ring-0 text-lg p-4"
                  placeholder="What's happening in your corner of the universe?"
                />
                
                <div className="flex gap-4 mt-4 items-center relative">
                  <button onClick={() => fileInputRef.current?.click()} className="flex items-center gap-2 text-primary">
                    <ImageIcon size={20} /> Upload
                  </button>
                  <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" multiple accept="image/*" />
                  
                  <button onClick={() => setShowEmojiPicker(!showEmojiPicker)} className="text-primary">
                    <Smile size={20} />
                  </button>

                  {showEmojiPicker && (
                    <div className="absolute top-10 left-0 z-[105]">
                      <EmojiPicker onEmojiClick={(e) => { setContent(c => c + e.emoji); setShowEmojiPicker(false) }} />
                    </div>
                  )}
                </div>
              </div>

              <div className="px-10 py-6 border-t flex justify-between">
                <button onClick={onClose} className="text-on-surface-variant">Discard</button>
                <Button onClick={handlePost} disabled={createPost.isPending || isUploading}>
                  {createPost.isPending ? 'Launching...' : 'Post Now'}
                </Button>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}