import { useState } from 'react'
import { motion } from 'framer-motion'
import { useNavigate } from 'react-router-dom'
import { Heart, MessageCircle, MoreHorizontal, Rocket, Image, Smile, Plus } from 'lucide-react'
import { Avatar } from '../ui/Avatar'
import { Badge } from '../ui/Badge'
import { Button } from '../ui/Button'
import { motionVariants } from '../../lib/theme'
import { useFeed, useCreatePost, useReactToPost } from '../../hooks/usePostsQuery'
import { useAuthStore } from '../../stores/authStore'

export function HomeFeedScreen() {
  const navigate = useNavigate()
  const user     = useAuthStore(s => s.user)

  const [newPostContent, setNewPostContent] = useState('')

  // ── Queries & mutations ────────────────────────────────────────────────────
  const { data: feed = [], isLoading, isError, error, refetch } = useFeed()

  const createPost  = useCreatePost()
  const reactToPost = useReactToPost()

  const posts   = feed.filter(p => p.type === 'POST')
  const stories = feed.filter(p => p.type === 'STORY')

  // ── Handlers ───────────────────────────────────────────────────────────────
  const handleCreatePost = (e: React.FormEvent) => {
    e.preventDefault()
    if (!newPostContent.trim() || createPost.isPending) return

    createPost.mutate(
      { content: newPostContent.trim(), visibility: 'PUBLIC' },
      { onSuccess: () => setNewPostContent('') },
    )
  }

  const handleReact = (postId: string) => {
    if (!user) return
    reactToPost.mutate({ postId, userId: user.id })
  }

  // ── Error message ──────────────────────────────────────────────────────────
  const errorMsg = isError
    ? ((error as any)?.response?.status === 500
        ? '' // empty DB — show empty state, not an error
        : ((error as any)?.response?.data?.message ?? 'Failed to sync with the celestial feed.'))
    : ''

  const avatarSeed = encodeURIComponent(user?.name ?? 'user')

  return (
    <div className="min-h-screen bg-[#f8f9ff] py-4 md:py-12 px-4 sm:px-6 md:px-8 lg:px-12 overflow-x-hidden select-none">
      <div className="max-w-[1200px] mx-auto grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8 lg:gap-12 items-start">

        {/* ── Main column ── */}
        <div className="w-full lg:col-span-2 space-y-6 md:space-y-8 overflow-hidden">

          {/* Stories strip */}
          <div className="flex gap-4 md:gap-5 overflow-x-auto pb-3 pt-1 no-scrollbar snap-x w-full">
            <div className="flex flex-col items-center flex-shrink-0 cursor-pointer group snap-start">
              <div className="w-16 h-16 md:w-20 md:h-20 rounded-full bg-gradient-to-tr from-[#6B46C0] to-[#00D4FF] p-[2px] transition-transform group-hover:scale-105 shadow-sm">
                <div className="w-full h-full rounded-full bg-white flex items-center justify-center">
                  <Plus size={24} className="text-primary" />
                </div>
              </div>
              <span className="text-[11px] md:text-xs font-bold text-on-surface-variant mt-1.5">Add Story</span>
            </div>

            {stories.map(story => (
              <div key={story.id} onClick={() => navigate('/stories')} className="flex flex-col items-center flex-shrink-0 cursor-pointer group snap-start">
                <div className="w-16 h-16 md:w-20 md:h-20 rounded-full bg-gradient-to-tr from-[#6B46C0] via-[#8E5EFF] to-[#00D4FF] p-[2px] transition-transform group-hover:scale-105 shadow-md">
                  <img
                    src={story.user.avatar || `https://api.dicebear.com/7.x/adventurer/svg?seed=${encodeURIComponent(story.user.name)}`}
                    alt={story.user.name}
                    className="w-full h-full rounded-full object-cover border-2 border-white"
                  />
                </div>
                <span className="text-[11px] md:text-xs font-bold text-on-surface mt-1.5 max-w-[65px] md:max-w-[80px] truncate">
                  {story.user.name}
                </span>
              </div>
            ))}
          </div>

          {/* Create post */}
          <div className="bg-white/80 backdrop-blur-md rounded-2xl md:rounded-[2rem] p-4 md:p-6 border border-white/60 shadow-sm">
            <form onSubmit={handleCreatePost} className="space-y-4">
              <div className="flex gap-3 md:gap-4 items-start">
                <Avatar src={`https://api.dicebear.com/7.x/adventurer/svg?seed=${avatarSeed}`} alt="Me" size="sm" className="md:w-12 md:h-12" />
                <textarea
                  value={newPostContent}
                  onChange={e => setNewPostContent(e.target.value)}
                  placeholder="Share your celestial thoughts..."
                  className="w-full bg-transparent border-none resize-none focus:outline-none text-on-surface placeholder-on-surface-variant/50 pt-1.5 min-h-[60px] md:min-h-[80px] text-sm md:text-base"
                />
              </div>
              <div className="h-px bg-outline-variant/20" />
              <div className="flex justify-between items-center">
                <div className="flex gap-0.5 md:gap-1 text-on-surface-variant/70">
                  <button type="button" className="p-2 hover:bg-surface rounded-xl transition-colors hover:text-primary"><Image size={20} /></button>
                  <button type="button" className="p-2 hover:bg-surface rounded-xl transition-colors hover:text-primary"><Smile size={20} /></button>
                </div>
                <Button
                  type="submit"
                  disabled={createPost.isPending || !newPostContent.trim()}
                  className="px-4 md:px-6 h-9 md:h-11 rounded-xl shadow-md min-w-[80px] md:min-w-[100px] text-xs md:text-sm bg-gradient-to-r from-[#6B46C0] to-[#8E5EFF] text-white hover:opacity-90"
                >
                  {createPost.isPending ? 'Launching...' : 'Launch'}
                </Button>
              </div>
            </form>
          </div>

          {/* Loading */}
          {isLoading && (
            <div className="text-center py-16 space-y-4">
              <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
              <p className="text-xs text-on-surface-variant font-semibold">Traversing the cosmos...</p>
            </div>
          )}

          {/* Error */}
          {errorMsg && (
            <div className="p-4 bg-red-50 border border-red-100 rounded-2xl text-center text-xs font-bold text-red-500">
              {errorMsg}
              <button onClick={() => refetch()} className="block mx-auto mt-2 text-xs text-primary underline font-bold">Retry</button>
            </div>
          )}

          {/* Empty */}
          {!isLoading && !errorMsg && posts.length === 0 && (
            <div className="text-center py-16 md:py-24 bg-white/40 rounded-2xl border-2 border-dashed border-outline-variant/30 px-4">
              <p className="text-on-surface-variant font-bold text-xs md:text-sm">Your constellation is empty. Start adding cosmic friends!</p>
            </div>
          )}

          {/* Feed */}
          {!isLoading && !errorMsg && (
            <div className="space-y-4 md:space-y-6">
              {posts.map(post => {
                const isLiked = post.reactions?.some(r => r.userId === user?.id)
                return (
                  <motion.div
                    key={post.id}
                    {...motionVariants.scaleIn}
                    className="bg-white rounded-2xl md:rounded-[2rem] border border-outline-variant/10 shadow-[0_4px_25px_rgba(0,0,0,0.01)] overflow-hidden"
                  >
                    {/* Header */}
                    <div className="p-4 md:p-6 flex justify-between items-center">
                      <div className="flex gap-3 md:gap-4 items-center cursor-pointer" onClick={() => navigate(`/post/${post.id}`)}>
                        <img
                          src={post.user?.avatar || `https://api.dicebear.com/7.x/adventurer/svg?seed=${encodeURIComponent(post.user?.name ?? 'User')}`}
                          alt={post.user?.name}
                          className="w-10 h-10 md:w-12 md:h-12 rounded-full object-cover shadow-sm border border-outline-variant/10"
                        />
                        <div>
                          <div className="flex items-center gap-1.5 md:gap-2">
                            <h3 className="font-bold text-on-surface text-sm md:text-base leading-tight">{post.user?.name}</h3>
                            <Badge variant="secondary" className="text-[9px] md:text-[10px] h-3.5 md:h-4 px-1 font-bold">Curator</Badge>
                          </div>
                          <span className="text-[10px] md:text-xs text-on-surface-variant/70 mt-0.5 inline-block">
                            {new Date(post.createdAt).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                      <button className="text-on-surface-variant/50 hover:text-on-surface p-1.5 hover:bg-surface rounded-xl transition-colors">
                        <MoreHorizontal size={18} />
                      </button>
                    </div>

                    {/* Content */}
                    <div className="px-4 md:px-6 pb-4 text-on-surface text-sm md:text-base leading-relaxed whitespace-pre-wrap cursor-pointer" onClick={() => navigate(`/post/${post.id}`)}>
                      {post.content}
                      {(post.hashtags?.length ?? 0) > 0 && (
                        <div className="flex flex-wrap gap-1.5 mt-2.5">
                          {post.hashtags!.map(tag => (
                            <span key={tag.id} className="text-[11px] font-extrabold text-primary hover:underline cursor-pointer">#{tag.name}</span>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Media */}
                    {(post.media?.length ?? 0) > 0 && (
                      <div className="bg-surface border-y border-outline-variant/10 overflow-hidden">
                        {post.media!.map(m => (
                          <img key={m.id} src={m.url} alt="Post media" className="w-full max-h-[400px] object-cover" />
                        ))}
                      </div>
                    )}

                    {/* Actions */}
                    <div className="p-2 md:p-3 px-4 md:px-6 flex justify-between items-center border-t border-outline-variant/5 text-[11px] font-bold text-on-surface-variant/80">
                      <div className="flex gap-1 md:gap-2 items-center">
                        <button
                          onClick={() => handleReact(String(post.id))}
                          disabled={reactToPost.isPending}
                          className={`flex items-center gap-1.5 p-2 hover:bg-surface rounded-xl transition-all active:scale-95 group ${isLiked ? 'text-red-500' : 'hover:text-red-500'}`}
                        >
                          <Heart size={18} className="group-hover:scale-110 transition-transform" fill={isLiked ? 'currentColor' : 'none'} />
                          <span>{post.reactions?.length ?? 0}</span>
                        </button>
                        <button
                          onClick={() => navigate(`/post/${post.id}`)}
                          className="flex items-center gap-1.5 p-2 hover:bg-surface hover:text-primary rounded-xl transition-all active:scale-95 group"
                        >
                          <MessageCircle size={18} className="group-hover:scale-110 transition-transform" />
                          <span>{post.comments?.length ?? 0}</span>
                        </button>
                      </div>
                      <button className="flex items-center gap-1.5 px-3 h-8 hover:bg-surface hover:text-primary rounded-xl transition-all">
                        <Rocket size={16} />
                        <span className="hidden sm:inline">Boost Focus</span>
                      </button>
                    </div>
                  </motion.div>
                )
              })}
            </div>
          )}
        </div>

        {/* ── Desktop sidebar ── */}
        <div className="space-y-8 hidden lg:block">
          <section className="bg-white/60 p-6 rounded-[2rem] border border-white/40 shadow-sm">
            <h4 className="text-xs font-extrabold font-headline uppercase tracking-widest text-on-surface-variant mb-6">Trending Constellations</h4>
            <div className="flex flex-col gap-5">
              {[
                { tag: '#Synthetica', count: '12.4k', desc: 'The evolution of digital environments.' },
                { tag: '#AuraDesign', count: '8.2k',  desc: 'Exploring high-fidelity premium interfaces.' },
                { tag: '#QuantumDev', count: '5.1k',  desc: 'Next-gen state architectures.' },
              ].map(t => (
                <div key={t.tag} className="flex flex-col cursor-pointer group">
                  <span className="text-sm text-primary font-extrabold mb-0.5 group-hover:underline">{t.tag}</span>
                  <span className="text-xs font-medium text-on-surface-variant/90 leading-normal">{t.desc}</span>
                  <span className="text-[10px] text-on-surface-variant/50 mt-1 uppercase font-bold tracking-wider">{t.count} Curations</span>
                </div>
              ))}
            </div>
          </section>

          <section className="bg-white/60 p-6 rounded-[2rem] border border-white/40 shadow-sm">
            <h4 className="text-xs font-extrabold font-headline uppercase tracking-widest text-on-surface-variant mb-6">Celestial Curators</h4>
            <div className="flex flex-col gap-4">
              {[
                { name: 'Marcus Sol', seed: 'Marcus' },
                { name: 'Luna Ray',   seed: 'Luna'   },
              ].map(u => (
                <div key={u.name} className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Avatar src={`https://api.dicebear.com/7.x/adventurer/svg?seed=${u.seed}`} alt={u.name} size="sm" className="border border-outline-variant/10 shadow-sm" />
                    <span className="text-sm font-bold text-on-surface">{u.name}</span>
                  </div>
                  <Button variant="secondary" size="sm" className="h-8 rounded-lg text-xs font-bold px-3">Orbit</Button>
                </div>
              ))}
            </div>
          </section>
        </div>

      </div>
    </div>
  )
}
